package pl.retsuz.parser;

public interface IParser {
    public void doParse();
}
