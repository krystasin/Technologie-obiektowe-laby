package pl.retsuz.filesystem;

public class TextFile extends GeneralComposite{
    String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
